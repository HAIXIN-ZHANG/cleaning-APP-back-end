module.exports = {
  apps: [
    {
      name: 'JR-P3-Back-End',
      script: './src/index.js'
    }
  ]
};
